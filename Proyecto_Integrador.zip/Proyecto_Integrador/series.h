#include <stdio.h>
#include "videos.h"
#include "episodios.h"
#ifndef series_h
#define series_h


class serie:public video{
    public:
    serie();
    serie(string nom, int dur, int ID, string gen,string title,int temp);
    void mostrar(), getDatEp(), setDatEp(), setEpisodios(int eps), getDatEpCalif();
    int getEpisodios();

    private:
    episodios listaEp[100];
    int ep;

};

serie::serie(){
    int n = 0;
    int ep = 0;

};
serie::serie(string nom, int dur, int ID, string gen,string title,int temp){
};
void serie::mostrar(){
    video::mostrar();
}

int serie::getEpisodios(){
    return ep;
}

void serie::setEpisodios(int eps){
    ep = eps;
}

void serie::setDatEp(){
    int temporada;
    string titulo;
    for (int i=0; i<ep; i++){
        cout<<endl<<"Episodio: "<<i+1<<endl<<"Define el título del episodio: ";
        cin>>titulo;
        listaEp[i].setNombre(titulo);
        cout<<"Define la teporada de la serie en la que esta el episodio: ";
        cin>>temporada;
        listaEp[i].setTemporada(temporada);
        cout<<"Define la calificación del episodio: ";
        listaEp[i].setCalificacion();
    }

    for(int i=ep; i<100; i++){
        listaEp[i].setNombre("0");
        listaEp[i].setTemporada(0);
    }
}

void serie::getDatEp(){
    cout<<"Número de Episodio   Título   Temporada   Calificación";
    for (int i=0; i<100; i++){
        if (listaEp[i].getNombre() != "0" or listaEp[i].getTemporada() != 0){
            cout<<endl<<"Episodio "<<i+1<<"   ";
            cout<<listaEp[i].getNombre()<<"   ";
            cout<<listaEp[i].getTemporada()<<"   ";
            cout<<listaEp[i].getCalificacion();
        }
    }
    cout<<endl;
}

void serie::getDatEpCalif(){
    int calif;
    cout<<"Inserte la calificación con la que se va a comprobar"<<endl;
    cin>>calif;
    cout<<"Número de Episodio   Título   Temporada   Calificación";
    for (int i=0; i<100; i++){
        if (listaEp[i].getNombre() != "0" or listaEp[i].getTemporada() != 0){
            if (listaEp[i].getCalificacion() == calif){
                cout<<endl<<"Episodio "<<i+1<<"   ";
                cout<<listaEp[i].getNombre()<<"   ";
                cout<<listaEp[i].getTemporada()<<"   ";
                cout<<listaEp[i].getCalificacion();
            }
        }
    }
    cout<<endl;
}


#endif