#include <stdio.h>
#ifndef videos_h
#define videos_h

class video{
    public:
    video();
    video(int ID,string nom,int dur,string gen, int cal);
    int getID();
    string getNombre();
    int getDuracion();
    string getGenero();
    int getCalificacion();
    void setID(int ID);
    void setNombre(string nom);
    void setDuracion(int dur);
    void setGenero(string gen);
    void setCalificacion();
    virtual void mostrar();

    private:
    string nombre;
    int duracion;
    int Id;
    string genero;
    int calificacion;
};


video::video(){
    nombre = "-";
    duracion = 0;
    Id = 0;
    genero = "-";
    calificacion = 0;
};

video::video(int ID,string nom,int dur,string gen, int cal){
    nombre = nom;
    duracion = dur;
    Id = ID;
    genero = gen;
    calificacion = cal;

};


void video::setNombre(string nom){
    nombre = nom;
};

string video::getNombre(){
    return nombre;
};

void video::setID(int ID){
    Id = ID;
};

int video::getID(){
    return Id;
};

void video::setDuracion(int dur){
    duracion = dur;
};

int video::getDuracion(){
    return duracion;
};
void video::setGenero(string gen){
    genero = gen;
};

string video::getGenero(){
    return genero;
};

void video::setCalificacion(){
    int cal;
    cin >> cal;
    if (cal >= 1 && cal <= 5){
        calificacion = cal;
    }
    else{
        cout << "La calificacion tiene que ser entre 1 y 5" << endl;
        setCalificacion();
    }
};

int video::getCalificacion (){
    return calificacion;
};

void video::mostrar(){
    cout<<"ID: "<< Id << endl;
    cout<<"Nombre: "<< nombre <<endl;
    cout<<"Duración: "<<duracion<<" min" << endl;
    cout<<"Genero: "<<genero<< endl;
    cout<<"Calificaciones: "<<calificacion<< endl;
};

#endif