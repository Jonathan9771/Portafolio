#include <stdio.h>
#include "videos.h"
#ifndef peliculas_h
#define peliculas_h


class pelicula:public video{
    public:
    pelicula();
    pelicula(int ID,string nom,int dur,string gen);
    void mostrar();
};

pelicula::pelicula(){
};

pelicula::pelicula(int ID,string nom,int dur,string gen){
};

void pelicula::mostrar(){
    video::mostrar();
}


#endif