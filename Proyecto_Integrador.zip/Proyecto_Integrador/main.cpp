#include <iostream>
#include <fstream>
using namespace std;
#include "videos.h"
#include "peliculas.h"
#include "series.h"
 
 void dataSeries(serie listaSerie[],int n){
    string nombre, gen;
    int ID, duracion, eps;
    
    for (int i = 0; i < n; i++){    
    cout << "Introduzca el nombre de la serie: " << endl;
    cin >> nombre;
    cout << "Introduzca el genero de la serie: " << endl;
    cin >> gen;
    cout << "Introduzca el ID de la serie: " << endl;
    cin >> ID;
    cout << "Introduzca la duración de la serie: " << endl;
    cin >> duracion;
    cout << "Introduzca la calificación de la serie: " << endl;
    listaSerie[i].setCalificacion();
    cout << "Introduzca los episodios de la serie: " << endl;
    cin >> eps;
    listaSerie[i].setNombre(nombre);
    listaSerie[i].setID(ID);
    listaSerie[i].setDuracion(duracion);
    listaSerie[i].setGenero(gen);
    
    listaSerie[i].setEpisodios(eps);
    listaSerie[i].setDatEp();
    }
 };
 
void dataPelicula(pelicula listaPelicula[],int n){
    string nombre, gen;
    int ID, duracion;
    
    for (int i = 0; i < n; i++){    
    cout << "Introduzca el nombre de la pelicula: " << endl;
    cin >> nombre;
    cout << "Introduzca el genero de la pelicula: " << endl;
    cin >> gen;
    cout << "Introduzca el ID de la pelicula: " << endl;
    cin >> ID;
    cout << "Introduzca la duración de la pelicula: " << endl;
    cin >> duracion;
    cout << "Introduzca la calificación de la pelicula: " << endl;
    listaPelicula[i].setNombre(nombre);
    listaPelicula[i].setID(ID);
    listaPelicula[i].setDuracion(duracion);
    listaPelicula[i].setGenero(gen);
    listaPelicula[i].setCalificacion();
    }
 };

void showPelicula(pelicula listaPelicula[], int n){
    for(int i = 0;i < n;i++){
        listaPelicula[i].mostrar();
    }
};

void showSerie(serie listaSerie[],int n){
     for(int i = 0;i < n;i++){
        listaSerie[i].mostrar();
    }
};

void buscarGenero(serie listaSerie[],pelicula listaPelicula[],int n, int n2){
    string genero;
    cout << "Introduzca el genero: " << endl;
    cin >> genero;
    for(int i = 0;i < n; i++){
        if (genero == listaSerie[i].getGenero()){
        listaSerie[i].mostrar();
        }
    }
    for(int i = 0;i < n2; i++){
        if (genero == listaPelicula[i].getGenero()){
        listaPelicula[i].mostrar();
        }
    }
};

void buscarCalificacion(serie listaSerie[],pelicula listaPelicula[],int n, int n2){
    int calificacion;
    cout << "Inserte la calificación: " << endl;
    cin >> calificacion;
    if (calificacion <= 1 || calificacion >= 5){
        cout << "No es una calificación valida" << endl;
    }
    else{
        for(int i = 0; i < n; i++){
            if (calificacion == listaSerie[i].getCalificacion() ){
                listaSerie[i].mostrar();
            }
        }
        for(int i = 0; i < n2; i++){
            if (calificacion == listaPelicula[i].getCalificacion() ){
                listaPelicula[i].mostrar();
            }
        }
    }
};

void buscarPeliculas(pelicula listaPelicula[], int n){
    int calificacion;
    cout << "Inserte la calificación: " << endl;
    cin >> calificacion;
    if (calificacion <= 1 || calificacion >= 5){
        cout << "No es una calificación valida" << endl;
    }    
    else{
        for(int i = 0; i < n; i++){
            if (calificacion == listaPelicula[i].getCalificacion()){
                listaPelicula[i].mostrar();
            }
        }
    }
};

void califVideo(serie listaSerie[],pelicula listaPelicula[],int n, int n2){
    string name;
    cout << "Introduzca el nombre del video a calificar: " << endl;
    cin >> name;
    for(int i = 0; i < n; i++){
        if (listaSerie[i].getNombre() == name){
            listaSerie[i].setCalificacion();
            showSerie(listaSerie,n);
            }
        }
    for(int i = 0; i < n2; i++){
        if (listaPelicula[i].getNombre() == name){
            listaPelicula[i].setCalificacion();
            showPelicula(listaPelicula,n2);
            }
        }
};

void episodiosCalif(serie listaSerie[], int n){
    string nom;
    int x = 1;
    cout<<endl<<"Nombre de la serie: "<<endl;
    cin>>nom;
    for (int i=0; i<n; i++){
        if(listaSerie[i].getNombre() == nom){
            listaSerie[i].getDatEpCalif();
            x = 0;
        }
    }
    if (x!=0){
        cout<<"No hay ningúna serie con ese id y nombre.";
        cin>>n;
    }
};

int main(){
    int n,n2;
    cout << "Introduzca el número de series: " << endl;
    cin >> n;
    cout << "Introduzca el número de peliculas: " <<endl;
    cin >> n2;
    serie listaSerie[n];
    pelicula listaPelicula[n2];

    dataSeries(listaSerie,n);
    dataPelicula(listaPelicula,n2);

    int caso, caso2;
    do{
        cout << "1. Cargar archivo de datos" << endl << "2. Mostrar los videos en general con cierta calificación o de un cierto género" << endl << "3. Mostrar los episodios de una determinada serie con una calificacion determinada " << endl << "4. Mostrar las peliculas con cierta calificacion " << endl << "5. Calificar un video" << endl << "0.Salir" << endl;
        cin >> caso;
        if (caso==1){
            main();
        }
        else if (caso == 2){
            cout << "1. Mostrar videos con cierta calificación"<< endl << "2. Mostrar videos con cierto genero" << endl;
            cin >> caso2;
            if (caso2 == 1){
                buscarCalificacion(listaSerie,listaPelicula,n,n2);
            }
            else if(caso2 == 2){
                buscarGenero(listaSerie,listaPelicula,n,n2);
            }
            else{
                cout << "Introduzca una opcion valida " << endl;
            }
        }
        else if (caso == 3){
            episodiosCalif(listaSerie,n);
        }
        else if (caso == 4){
            buscarPeliculas(listaPelicula,n);

        }
        else if (caso == 5){
            califVideo(listaSerie,listaPelicula,n,n2);
        }
        else{
            cout << "Introduzca una opcion valida " << endl;
        }
    }
    while(caso != 0);
};