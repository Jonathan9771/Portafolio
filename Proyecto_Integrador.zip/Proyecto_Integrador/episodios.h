#ifndef episodios_h
#define episodios_h
#include "episodios.h"
class episodios:public video {
    public:
        episodios();
        int getTemporada();
        void setTemporada(int);
    private:
        int temporada;
};

episodios::episodios(){
    temporada = 0; 
}

int episodios::getTemporada(){
    return temporada;
}

void episodios::setTemporada(int temp){
    temporada = temp;
}
#endif // episodios_h